import EmployeeTable from './employee';
import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {
  return (
    <div>
      <EmployeeTable />
    </div>
  );
};

export default App;
